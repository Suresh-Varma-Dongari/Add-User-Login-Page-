let myForm = document.getElementById("myForm");
myForm.addEventListener("submit", function(event) {
    event.preventDefault();
});

let Name = document.getElementById("name");
let pr = document.getElementById("ErrorMesg");
Name.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        pr.textContent = "Requried*";
    } else {
        pr.textContent = "";
    }
});

let Email = document.getElementById("email");
let Epr = document.getElementById("EmailMsg");
Email.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        Epr.textContent = "Requried*";
    } else {
        Epr.textContent = "";
    }
});